import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/foundation.dart';
import '../data/firebase_config.dart';

final authStateProvider = StreamProvider<User?>((ref) {
  if (!FirebaseRuntime.initialized) {
    return Stream.value(null);
  }
  return FirebaseAuth.instance.userChanges();
});

class AuthController {
  /// Returns:
  /// - `null` if login succeeded and email is verified
  /// - `'EMAIL_NOT_VERIFIED'` if password is valid but email link hasn't been clicked yet
  /// - Any other `String` for Firebase error messages
  Future<String?> login(String email, String password) async {
    if (!FirebaseRuntime.initialized) {
      return 'Firebase is not initialized. Did you run the script?';
    }
    try {
      final credential = await FirebaseAuth.instance.signInWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Reload user to fetch the latest emailVerified flag from Firebase
      await credential.user?.reload();
      final refreshedUser = FirebaseAuth.instance.currentUser;

      if (refreshedUser != null && !refreshedUser.emailVerified) {
        return 'EMAIL_NOT_VERIFIED';
      }

      return null;
    } on FirebaseAuthException catch (e) {
      debugPrint("LOGIN ERROR CODE: ${e.code}");
      debugPrint("LOGIN ERROR MESSAGE: ${e.message}");
      return e.message;
    } catch (e) {
      debugPrint("LOGIN ERROR: $e");
      return e.toString();
    }
  }

  Future<String?> register(String email, String password) async {
    if (!FirebaseRuntime.initialized) {
      return 'Firebase is not initialized. Did you run the script?';
    }
    try {
      final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );

      // Send verification link immediately upon registration
      await credential.user?.sendEmailVerification();

      // Sign out so the user must verify their email before logging in
      await FirebaseAuth.instance.signOut();
      return null;
    } on FirebaseAuthException catch (e) {
      debugPrint("REGISTER ERROR CODE: ${e.code}");
      debugPrint("REGISTER ERROR MESSAGE: ${e.message}");
      return e.message;
    } catch (e) {
      debugPrint("REGISTER ERROR: $e");
      return e.toString();
    }
  }

  Future<String?> resendVerificationEmail() async {
    try {
      final user = FirebaseAuth.instance.currentUser;
      if (user != null && !user.emailVerified) {
        await user.sendEmailVerification();
      }
      return null;
    } on FirebaseAuthException catch (e) {
      return e.message;
    } catch (e) {
      return e.toString();
    }
  }

  /// Sign in with a Google account.
  Future<String?> signInWithGoogle() async {
    if (!FirebaseRuntime.initialized) {
      return 'Firebase is not initialized. Did you run the script?';
    }

    if (!kIsWeb) {
      return 'Google sign-in is enabled on the web build. '
          'On Android/iOS add the google_sign_in package (see docs/FIREBASE.md).';
    }

    try {
      final provider = GoogleAuthProvider();
      provider.setCustomParameters({'prompt': 'select_account'});

      try {
        final credential =
            await FirebaseAuth.instance.signInWithPopup(provider);
        if (credential.user == null) return 'Google sign-in was cancelled.';
        return null;
      } on FirebaseAuthException catch (popupError) {
        final blocked = popupError.code == 'popup-blocked' ||
            popupError.code == 'operation-not-supported-in-this-environment';
        if (!blocked) rethrow;

        debugPrint('Popup blocked (${popupError.code}); using redirect flow.');
        await FirebaseAuth.instance.signInWithRedirect(provider);
        return null;
      }
    } on FirebaseAuthException catch (e) {
      debugPrint('GOOGLE SIGN-IN ERROR CODE: ${e.code}');
      debugPrint('GOOGLE SIGN-IN ERROR MESSAGE: ${e.message}');
      if (e.code == 'popup-closed-by-user' ||
          e.code == 'cancelled-popup-request') {
        return null;
      }
      return e.message;
    } catch (e) {
      debugPrint('GOOGLE SIGN-IN ERROR: $e');
      return e.toString();
    }
  }

  Future<String?> sendPasswordReset(String email) async {
    if (!FirebaseRuntime.initialized) {
      return 'Firebase is not initialized. Did you run the script?';
    }
    try {
      await FirebaseAuth.instance.sendPasswordResetEmail(email: email);
      return null;
    } on FirebaseAuthException catch (e) {
      debugPrint("RESET PASSWORD ERROR CODE: ${e.code}");
      return e.message;
    } catch (e) {
      debugPrint("RESET PASSWORD ERROR: $e");
      return e.toString();
    }
  }

  Future<void> logout() async {
    if (FirebaseRuntime.initialized) {
      await FirebaseAuth.instance.signOut();
    }
  }
}

final authControllerProvider = Provider<AuthController>((ref) {
  return AuthController();
});